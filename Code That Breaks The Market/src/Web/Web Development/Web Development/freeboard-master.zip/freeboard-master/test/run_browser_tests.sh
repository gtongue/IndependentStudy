cd "$( dirname "$0" )"
cd ..
casperjs test test/casper/tests/
